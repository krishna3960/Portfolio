export const JavaProjects = [
    {
        id : 1 ,
        title : "Personal Portfolio Java",
        desc : "This is a personal portfolio I built from Scratch using React",
        img : "https://icon-library.com/images/twitter-small-icon/twitter-small-icon-17.jpg"
    }, 
    {
        id : 2 ,
        title : "Personal Portfolio Java",
        desc : "This is a personal portfolio I built from Scratch using React",
        img : "https://icon-library.com/images/twitter-small-icon/twitter-small-icon-17.jpg"
    },
    {
        id : 3 ,
        title : "Personal Portfolio Java",
        desc : "This is a personal portfolio I built from Scratch using React",
        img : "https://icon-library.com/images/twitter-small-icon/twitter-small-icon-17.jpg"
    }, 
    {
        id : 4 ,
        title : "Personal Portfolio Java",
        desc : "This is a personal portfolio I built from Scratch using React",
        img : "https://icon-library.com/images/twitter-small-icon/twitter-small-icon-17.jpg"
    },
];

export const PythonProjects = [
    {
        id : 1 ,
        title : "Personal Portfolio Python",
        desc : "This is a personal portfolio I built from Scratch using React",
        img : "https://icon-library.com/images/twitter-small-icon/twitter-small-icon-17.jpg"
    },
    {
        id : 2 ,
        title : "Personal Portfolio Python",
        desc : "This is a personal portfolio I built from Scratch using React",
        img : "https://icon-library.com/images/twitter-small-icon/twitter-small-icon-17.jpg"
    },
    {
        id : 3 ,
        title : "Milena la tchoin",
        desc : "Milenkooo ",
        img  : "https://pbs.twimg.com/profile_images/923052420699181056/-WG6-tBu.jpg"
    },
    {
        id : 4 ,
        title : "Milena la tchoin",
        desc : "Milenkooo ",
        img  : "https://pbs.twimg.com/profile_images/923052420699181056/-WG6-tBu.jpg"
    },
    
];

export const Reactprojects = [
    {
        id : 1 ,
        title : "Personal Portfolio React",
        desc : "This is a personal portfolio I built from Scratch using React",
        img : "https://icon-library.com/images/twitter-small-icon/twitter-small-icon-17.jpg"
    }
];